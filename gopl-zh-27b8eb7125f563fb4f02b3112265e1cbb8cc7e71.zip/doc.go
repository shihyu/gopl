// Copyright 2015 Golang-China. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//
// Go圣经中文版.
//
// 在线版本: http://golang-china.github.io/gopl-zh
//
// 离线版本: http://github.com/golang-china/gopl-zh/archive/gh-pages.zip
//
// 项目主页: http://github.com/golang-china/gopl-zh
//
// 原版官网: http://gopl.io
//
package gopl_zh
